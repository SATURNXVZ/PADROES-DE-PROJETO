package AULA 3;

public package aula01;

public class programa {
    public static void main(String[] args) {
        finance fin = new finance();
        gerente coord = new gerente();

        coord.nome = "Irvando";
        coord.salario = (double) 10000;
        coord.num = 2;
        //System.out.println(coord.getBonificacao());
        
        operador porteiro = new operador();
        porteiro.nome = "Jucelino";
        porteiro.salario = (double) 1500;

        gerente coord1 = new gerente();
        fin.calc_bonus(coord);
        fin.calc_bonus(coord1);
        fin.calc_bonus(porteiro);

        funcionario func = new gerente();
        func.nome = "Igor";
        func.salario = (double) 20000;
        

            

        System.out.println(func.getTotal_bonus());
        
    }  
} {
    
}
